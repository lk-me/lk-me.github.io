﻿#include <windows.h>
#include <string>

#pragma comment(lib, "user32.lib")
#pragma comment(lib, "gdi32.lib")

// 全局变量
HWND g_hPasswordEdit = NULL;
HFONT g_hWingdingsFont = NULL;

// 窗口过程
LRESULT CALLBACK WindowProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    switch (uMsg)
    {
    case WM_CREATE:
    {
        // 创建说明
        CreateWindow(L"STATIC", L"密码输入框 - 使用 EM_SETPASSWORDCHAR 显示黑圆圈",
            WS_VISIBLE | WS_CHILD,
            20, 20, 400, 20, hwnd, NULL, NULL, NULL);

        // 创建密码编辑框
        g_hPasswordEdit = CreateWindow(
            L"EDIT",
            L"",
            WS_VISIBLE | WS_CHILD | WS_BORDER | ES_PASSWORD | ES_MULTILINE |ES_PASSWORD,
            20, 50, 300, 30,
            hwnd, (HMENU)1001, NULL, NULL
        );

        // 创建 Wingdings 字体
        g_hWingdingsFont = CreateFont(
            20, 0, 0, 0, FW_NORMAL, FALSE, FALSE, FALSE,
            DEFAULT_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,
            DEFAULT_QUALITY, DEFAULT_PITCH, L"Wingdings"
        );

        // 设置 Wingdings 字体
        if (g_hWingdingsFont)
        {
            SendMessage(g_hPasswordEdit, WM_SETFONT, (WPARAM)g_hWingdingsFont, TRUE);
        }

        // 关键：设置密码字符为 Wingdings 字体的 'l'（小黑圈）
        SendMessage(g_hPasswordEdit, EM_SETPASSWORDCHAR, (WPARAM)L'l', 0);

        // 创建功能按钮
        CreateWindow(L"BUTTON", L"获取密码内容",
            WS_VISIBLE | WS_CHILD,
            20, 90, 120, 30, hwnd, (HMENU)1002, NULL, NULL);

        CreateWindow(L"BUTTON", L"清空",
            WS_VISIBLE | WS_CHILD,
            150, 90, 80, 30, hwnd, (HMENU)1003, NULL, NULL);

        CreateWindow(L"BUTTON", L"测试输入",
            WS_VISIBLE | WS_CHILD,
            240, 90, 80, 30, hwnd, (HMENU)1004, NULL, NULL);

        CreateWindow(L"BUTTON", L"切换显示/隐藏",
            WS_VISIBLE | WS_CHILD,
            20, 130, 120, 30, hwnd, (HMENU)1005, NULL, NULL);

        // 创建显示区域
        CreateWindow(L"STATIC", L"Wingdings 字体演示:",
            WS_VISIBLE | WS_CHILD,
            20, 170, 150, 20, hwnd, NULL, NULL, NULL);

        // 显示各种 Wingdings 字符
        struct WingdingChar {
            wchar_t ch;
            const wchar_t* desc;
        };

        WingdingChar chars[] = {
            {L'l', L"'l' = 黑圆圈 (密码字符)"},
            {L'L', L"'L' = 大黑圆圈"},
            {L'!', L"'!' = 笑脸"},
            {L'J', L"'J' = 箭头"}
        };

        for (int i = 0; i < 4; i++)
        {
            HWND hChar = CreateWindow(L"STATIC", L" ",
                WS_VISIBLE | WS_CHILD | SS_CENTER | SS_CENTERIMAGE,
                20 + i * 80, 195, 30, 30, hwnd, NULL, NULL, NULL);

            wchar_t text[2] = { chars[i].ch, L'\0' };
            SetWindowText(hChar, text);

            if (g_hWingdingsFont)
            {
                SendMessage(hChar, WM_SETFONT, (WPARAM)g_hWingdingsFont, TRUE);
            }

            CreateWindow(L"STATIC", chars[i].desc,
                WS_VISIBLE | WS_CHILD,
                20 + i * 80, 225, 80, 40, hwnd, NULL, NULL, NULL);
        }

        // 状态显示
        CreateWindow(L"STATIC", L"状态: 密码模式 - 输入显示为黑圆圈",
            WS_VISIBLE | WS_CHILD,
            20, 270, 300, 20, hwnd, (HMENU)1006, NULL, NULL);
    }
    break;

    case WM_COMMAND:
    {
        int id = LOWORD(wParam);
        static BOOL bPasswordVisible = FALSE;

        switch (id)
        {
        case 1002: // 获取密码内容
        {
            wchar_t buffer[256];
            GetWindowText(g_hPasswordEdit, buffer, 256);

            if (wcslen(buffer) > 0)
            {
                wchar_t msg[512];
                swprintf_s(msg, 512,
                    L"密码内容: %ls\n"
                    L"长度: %d 字符",
                    buffer,
                    wcslen(buffer));
                MessageBox(hwnd, msg, L"密码内容", MB_OK);
            }
            else
            {
                MessageBox(hwnd, L"没有输入内容", L"提示", MB_OK);
            }
        }
        break;

        case 1003: // 清空
            SetWindowText(g_hPasswordEdit, L"");
            break;

        case 1004: // 测试输入
            SetWindowText(g_hPasswordEdit, L"TestPassword123");
            break;

        case 1005: // 切换显示/隐藏
        {
            bPasswordVisible = !bPasswordVisible;

            if (bPasswordVisible)
            {
                // 显示明文
                SendMessage(g_hPasswordEdit, EM_SETPASSWORDCHAR, 0, 0);
                SetWindowText(GetDlgItem(hwnd, 1006), L"状态: 明文模式 - 显示实际字符");
            }
            else
            {
                // 显示黑圆圈
                SendMessage(g_hPasswordEdit, EM_SETPASSWORDCHAR, (WPARAM)L'l', 0);
                SetWindowText(GetDlgItem(hwnd, 1006), L"状态: 密码模式 - 输入显示为黑圆圈");
            }

            // 强制重绘
            InvalidateRect(g_hPasswordEdit, NULL, TRUE);
            UpdateWindow(g_hPasswordEdit);
        }
        break;
        }
    }
    break;

    case WM_DESTROY:
        if (g_hWingdingsFont)
        {
            DeleteObject(g_hWingdingsFont);
        }
        PostQuitMessage(0);
        break;
    }

    return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

// 程序入口
int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
    // 注册窗口类
    WNDCLASS wc = {};
    wc.lpfnWndProc = WindowProc;
    wc.hInstance = hInstance;
    wc.lpszClassName = L"PasswordCharDemo";
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);

    RegisterClass(&wc);

    // 创建窗口
    HWND hwnd = CreateWindow(
        L"PasswordCharDemo",
        L"EM_SETPASSWORDCHAR 黑圆圈演示",
        WS_OVERLAPPEDWINDOW,
        CW_USEDEFAULT, CW_USEDEFAULT, 450, 350,
        NULL, NULL, hInstance, NULL
    );

    ShowWindow(hwnd, nCmdShow);
    UpdateWindow(hwnd);

    // 消息循环
    MSG msg = {};
    while (GetMessage(&msg, NULL, 0, 0))
    {
        TranslateMessage(&msg);
        DispatchMessage(&msg);
    }

    return 0;
}